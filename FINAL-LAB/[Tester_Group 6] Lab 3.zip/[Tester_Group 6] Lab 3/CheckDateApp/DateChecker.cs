﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CheckDateApp
{
    public class DateChecker
    {
        public int DaysInMonth(int year, int month)
        {
            if (month < 1 || month > 12)
            {
                Console.WriteLine("Invalid month");
                return 0;
            }

            if (month == 2)
            {
                return DateTime.IsLeapYear(year) ? 29 : 28;
            }

            if (month == 4 || month == 6 || month == 9 || month == 11)
            {
                return 30;
            }

            return 31;
        }

        public bool IsValidDate(int year, int month, int day)
        {
            if (month < 1 || month > 12)
            {
                Console.WriteLine("Invalid month");
                return false;
            }

            if (day < 1)
            {
                Console.WriteLine("Day cannot be below 1");
                return false;
            }

            if (day > DaysInMonth(year, month))
            {
                Console.WriteLine("Day exceeds max days in month");
                return false;
            }

            Console.WriteLine("Valid date");
            return true;
        }
    }
}
