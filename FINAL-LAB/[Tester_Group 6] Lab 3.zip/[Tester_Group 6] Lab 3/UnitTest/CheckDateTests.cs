namespace DaysInMonthUnitTest

{
    [TestFixture]
    public class DateCheckerTests
    {
        private DateChecker dateChecker;

        [SetUp]
        public void Setup()
        {
            dateChecker = new DateChecker();
        }

        [Test]
        public void TestIsValidDate_InvalidMonth_LessThanOne()
        {
            int year = 2023, month = 0, day = 15;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for invalid month (less than 1)");
        }

        [Test]
        public void TestIsValidDate_InvalidMonth_GreaterThanTwelve()
        {
            int year = 2023, month = 13, day = 15;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for invalid month (greater than 12)");
        }

        [Test]
        public void TestIsValidDate_DayBelowOne()
        {
            int year = 2023, month = 2, day = 0;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for day below 1");
        }

        [Test]
        public void TestIsValidDate_ValidDate_FebruaryFirst()
        {
            int year = 2023, month = 2, day = 1;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsTrue(result, "Expected true for a valid date: 1st February 2023");
        }

        [Test]
        public void TestIsValidDate_ValidDate_FebruaryNonLeapYear()
        {
            int year = 2023, month = 2, day = 28;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsTrue(result, "Expected true for a valid date: 28th February 2023");
        }

        [Test]
        public void TestIsValidDate_InvalidDate_FebruaryNonLeapYear()
        {
            int year = 2023, month = 2, day = 29;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for 29th February 2023 (non-leap year)");
        }

        [Test]
        public void TestIsValidDate_ValidDate_FebruaryLeapYear()
        {
            int year = 2024, month = 2, day = 29;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsTrue(result, "Expected true for a valid date: 29th February 2024 (leap year)");
        }

        [Test]
        public void TestIsValidDate_InvalidDate_ThirtyOneDaysInApril()
        {
            int year = 2023, month = 4, day = 31;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for 31st April 2023 (only 30 days in April)");
        }

        [Test]
        public void TestIsValidDate_InvalidDate_ThirtyOneDaysInJune()
        {
            int year = 2023, month = 6, day = 31;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsFalse(result, "Expected false for 31st June 2023 (only 30 days in June)");
        }

        [Test]
        public void TestIsValidDate_ValidDate_EndOfYear()
        {
            int year = 2023, month = 12, day = 31;
            bool result = dateChecker.IsValidDate(year, month, day);
            Assert.IsTrue(result, "Expected true for a valid date: 31st December 2023");
        }
    }
}
