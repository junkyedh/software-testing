global using NUnit.Framework;
global using CheckDateApp;