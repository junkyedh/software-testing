using CheckDateApp;
using NUnit.Framework;
using CheckDateApp;

namespace DaysInMonthUnitTest
{
    public class DayInMonthTests
    {
        private DateChecker _dateChecker;

        [SetUp]
        public void Setup()
        {
            _dateChecker = new DateChecker();
        }

        [Test]
        public void DaysInMonth_FebruaryLeapYear_Returns29()
        {
            int result = _dateChecker.DaysInMonth(2020, 2);
            Assert.That(result, Is.EqualTo(29));
        }

        [Test]
        public void DaysInMonth_FebruaryNonLeapYear_Returns28()
        {
            int result = _dateChecker.DaysInMonth(2019, 2);
            Assert.That(result, Is.EqualTo(28));
        }

        [Test]
        public void DaysInMonth_April_Returns30()
        {
            int result = _dateChecker.DaysInMonth(2021, 4);
            Assert.That(result, Is.EqualTo(30));
        }

        [Test]
        public void DaysInMonth_January_Returns31()
        {
            int result = _dateChecker.DaysInMonth(2021, 1);
            Assert.That(result, Is.EqualTo(31));
        }

        [Test]
        public void DaysInMonth_InvalidMonth_Returns0()
        {
            int result = _dateChecker.DaysInMonth(2021, 13);
            Assert.That(result, Is.EqualTo(0));
        }

        [Test]
        public void DaysInMonth_NegativeMonth_Returns0()
        {
            int result = _dateChecker.DaysInMonth(2021, -1);
            Assert.That(result, Is.EqualTo(0));
        }
    }
}